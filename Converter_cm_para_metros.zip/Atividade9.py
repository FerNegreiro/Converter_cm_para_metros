import tkinter as tk

def converter_cm_para_metros():
    try:
        # Obtém o valor em centímetros do Entry
        cm = float(entry_cm.get())
        # Converte para metros
        metros = cm / 100
        # Atualiza o texto do Label com o resultado da conversão
        label_resultado.config(text=f"{cm} centímetros é igual a {metros} metros.")
    except ValueError:
        # Caso ocorra uma exceção de valor inválido, mostra uma mensagem de erro
        label_resultado.config(text="Por favor, insira um valor válido.")

# Cria a janela principal
root = tk.Tk()
root.title("Conversor de Centímetros para Metros")

# Cria um frame para organizar os widgets
frame = tk.Frame(root)
frame.pack(padx=20, pady=20)

# Cria um Entry para o usuário inserir a quantidade em centímetros
entry_cm = tk.Entry(frame)
entry_cm.pack()

# Cria um botão para realizar a conversão
button_convert = tk.Button(frame, text="Converter", command=converter_cm_para_metros)
button_convert.pack(pady=10)

# Cria um Label para exibir o resultado da conversão
label_resultado = tk.Label(frame, text="")
label_resultado.pack()

# Inicia o loop de eventos da janela
root.mainloop()
